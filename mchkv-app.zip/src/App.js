
import React, { useState, useEffect } from "react";
import { createClient } from "@supabase/supabase-js";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer } from "recharts";

const supabase = createClient("YOUR_SUPABASE_URL","YOUR_SUPABASE_KEY");
const API_KEY = "YOUR_YOUTUBE_API_KEY";

export default function App(){
  const [session,setSession] = useState(null);
  const [query,setQuery] = useState("");
  const [channel,setChannel] = useState(null);
  const [history,setHistory] = useState([]);
  const [theme,setTheme] = useState(localStorage.getItem("theme") || "dark");

  useEffect(()=>{
    supabase.auth.getSession().then(({data})=> setSession(data.session));
  },[]);

  useEffect(()=>{
    document.body.style.background = theme==="dark"?"#0f172a":"#ffffff";
    document.body.style.color = theme==="dark"?"#fff":"#000";
    localStorage.setItem("theme",theme);
  },[theme]);

  const login = async()=>{
    await supabase.auth.signInWithPassword({
      email: prompt("Email"),
      password: prompt("Password")
    });
    window.location.reload();
  };

  const signup = async()=>{
    await supabase.auth.signUp({
      email: prompt("Email"),
      password: prompt("Password")
    });
    alert("Check your email!");
  };

  const search = async()=>{
    const res = await fetch(`https://www.googleapis.com/youtube/v3/search?part=snippet&type=channel&q=${query}&key=${API_KEY}`);
    const data = await res.json();
    if(data.items.length){
      const id = data.items[0].snippet.channelId;
      getChannel(id);
    }
  };

  const getChannel = async(id)=>{
    const res = await fetch(`https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=${id}&key=${API_KEY}`);
    const data = await res.json();
    const ch = data.items[0];
    setChannel(ch);

    const point = {date:new Date().toLocaleTimeString(), subs:Number(ch.statistics.subscriberCount)};
    setHistory(prev=>[...prev.slice(-9),point]);
  };

  const track = async()=>{
    await supabase.from("tracking").insert({channel_id: channel.id});
    alert("Tracked!");
  };

  if(!session){
    return (
      <div style={{padding:20}}>
        <h1>MCHKV</h1>
        <button onClick={()=>setTheme("dark")}>Dark</button>
        <button onClick={()=>setTheme("light")}>Light</button>
        <button onClick={login}>Login</button>
        <button onClick={signup}>Sign Up</button>
      </div>
    );
  }

  return (
    <div style={{padding:20}}>
      <h1>MCHKV Dashboard</h1>

      <input value={query} onChange={e=>setQuery(e.target.value)} placeholder="Search channel"/>
      <button onClick={search}>Search</button>

      {channel && (
        <div>
          <h2>{channel.snippet.title}</h2>
          <p>Subs: {Number(channel.statistics.subscriberCount).toLocaleString()}</p>
          <button onClick={track}>Track</button>

          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={history}>
              <XAxis dataKey="date"/>
              <YAxis/>
              <Tooltip/>
              <Line dataKey="subs"/>
            </LineChart>
          </ResponsiveContainer>
        </div>
      )}
    </div>
  );
}
